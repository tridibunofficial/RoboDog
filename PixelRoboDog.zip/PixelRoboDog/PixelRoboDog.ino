#include <ESP32Servo.h>
#include <math.h>
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "driver/i2s.h"

#include "pixel_ready.h"
#include "pixel_info.h"
#include "bark.h"
#include "gallop.h"

#ifndef I2S_COMM_FORMAT_STAND_I2S
#define I2S_COMM_FORMAT_STAND_I2S I2S_COMM_FORMAT_I2S
#endif

#include <FluxGarage_RoboEyes.h>
#undef N
#undef E
#undef S
#undef W
#undef NE
#undef NW
#undef SE
#undef SW

// =====================================================
// DISPLAY
// =====================================================
#define I2C_SDA       21
#define I2C_SCL       22
#define i2c_Address   0x3c
#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
RoboEyes<Adafruit_SSD1306> roboEyes(display);
#define OLED_WHITE SSD1306_WHITE
#define OLED_BLACK SSD1306_BLACK

// =====================================================
// LOCAL 8-BIT PCM AUDIO CLIPS FROM HEADER FILES
// -----------------------------------------------------
// These .h files must be in the same folder as PixelRoboDog.ino.
// No SPIFFS/LittleFS/data upload is needed.
// =====================================================
struct AudioClip {
  const uint8_t* data;
  uint32_t length;
  uint32_t sampleRate;
};

const AudioClip PIXEL_READY_CLIP  = { pixel_ready_4, pixel_ready_4_len, pixel_ready_4_sampleRate };
const AudioClip PIXEL_INFO_CLIP   = { pixel_info_4,  pixel_info_4_len,  pixel_info_4_sampleRate  };
const AudioClip PIXEL_GALLOP_CLIP = { gallop_3,      gallop_3_len,      gallop_3_sampleRate      };
const AudioClip PIXEL_BARK_CLIP   = { bark_3,        bark_3_len,        bark_3_sampleRate        };

#define CLIP_READY   0
#define CLIP_INFO    1
#define CLIP_GALLOP  2
#define CLIP_BARK    3

const AudioClip* AUDIO_CLIPS[] = {
  &PIXEL_READY_CLIP,
  &PIXEL_INFO_CLIP,
  &PIXEL_GALLOP_CLIP,
  &PIXEL_BARK_CLIP
};

// MAX98357 I2S amplifier pins
#define AMP_I2S_PORT      I2S_NUM_0
#define AMP_BCLK_PIN      26
#define AMP_LRC_PIN       25
#define AMP_DIN_PIN       33

// INMP441 I2S microphone pins
#define MIC_I2S_PORT      I2S_NUM_1
#define MIC_SCK_PIN       14
#define MIC_WS_PIN        15
#define MIC_SD_PIN        32
#define MIC_SAMPLE_RATE   16000
#define MIC_WAKE_LEVEL    900L
#define MIC_LISTEN_MS     5000

// Set INMP441 L/R pin to GND for LEFT. If you connect L/R to 3.3V,
// change this to I2S_CHANNEL_FMT_ONLY_RIGHT.
#define MIC_CHANNEL       I2S_CHANNEL_FMT_ONLY_LEFT

bool audioPlaying = false;
const AudioClip* currentClip = nullptr;
uint32_t audioByteIndex = 0;
bool audioReturnToNormal = false;
bool audioMoodReturnPending = false;
bool voiceAwake = false;
unsigned long voiceAwakeUntil = 0;
bool infoPresentationActive = false;
bool infoPresentationHasAudio = false;
unsigned long infoPresentationStartedAt = 0;

void handleCommand(String input);

void initAudioOut() {
  i2s_config_t config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = 8000,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num = AMP_BCLK_PIN,
    .ws_io_num = AMP_LRC_PIN,
    .data_out_num = AMP_DIN_PIN,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  i2s_driver_install(AMP_I2S_PORT, &config, 0, NULL);
  i2s_set_pin(AMP_I2S_PORT, &pins);
}

void initMic() {
  i2s_config_t config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = MIC_SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = MIC_CHANNEL,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 4,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num = MIC_SCK_PIN,
    .ws_io_num = MIC_WS_PIN,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = MIC_SD_PIN
  };
  i2s_driver_install(MIC_I2S_PORT, &config, 0, NULL);
  i2s_set_pin(MIC_I2S_PORT, &pins);
}

void stopWav() {
  audioPlaying = false;
  audioReturnToNormal = false;
  currentClip = nullptr;
  audioByteIndex = 0;
  i2s_zero_dma_buffer(AMP_I2S_PORT);
}

bool startClip(uint8_t clipId, bool returnToNormalWhenDone) {
  stopWav();
  if (clipId >= sizeof(AUDIO_CLIPS) / sizeof(AUDIO_CLIPS[0])) {
    Serial.println("Invalid audio clip");
    return false;
  }

  currentClip = AUDIO_CLIPS[clipId];
  audioByteIndex = 0;
  audioReturnToNormal = returnToNormalWhenDone;
  i2s_set_clk(AMP_I2S_PORT, currentClip->sampleRate, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO);
  audioPlaying = true;
  return true;
}

void serviceAudio() {
  if (!audioPlaying || currentClip == nullptr) return;

  int16_t out[256];
  uint32_t remaining = currentClip->length - audioByteIndex;
  size_t samples = remaining > sizeof(out) / sizeof(out[0]) ? sizeof(out) / sizeof(out[0]) : remaining;
  if (samples == 0) {
    bool shouldReturn = audioReturnToNormal;
    stopWav();
    if (shouldReturn) audioMoodReturnPending = true;
    return;
  }

  for (size_t i = 0; i < samples; i++) {
    uint8_t u = pgm_read_byte(currentClip->data + audioByteIndex + i);
    out[i] = ((int16_t)u - 128) << 8;
  }

  size_t written = 0;
  i2s_write(AMP_I2S_PORT, out, samples * sizeof(int16_t), &written, 0);
  audioByteIndex += samples;
}

void serviceWav() {
  serviceAudio();
}

bool startWav(uint8_t clipId) {
  return startClip(clipId, false);
}

bool startMoodWav(uint8_t clipId) {
  return startClip(clipId, true);
}

void audioDelay(unsigned long ms) {
  unsigned long until = millis() + ms;
  while ((long)(millis() - until) < 0) {
    serviceWav();
    delay(1);
  }
}

long readMicEnergy() {
  int32_t samples[128];
  size_t bytesRead = 0;
  i2s_read(MIC_I2S_PORT, samples, sizeof(samples), &bytesRead, pdMS_TO_TICKS(10));
  int count = bytesRead / sizeof(int32_t);
  if (count == 0) return 0;

  int64_t sum = 0;
  for (int i = 0; i < count; i++) {
    int32_t s = samples[i] >> 14;
    sum += abs(s);
  }
  return (long)(sum / count);
}

// A raw INMP441 cannot understand words by itself. Replace this function with
// ESP-SR, Edge Impulse, or another speech recognizer and return commands like:
// REST, INFO, WALK, BACK, LEFT, RIGHT, SL, SR, STOP, BARK, GALLOP.
String recognizeVoiceCommand() {
  return "";
}

void updateVoiceInput() {
  long energy = readMicEnergy();

  if (!voiceAwake && energy > MIC_WAKE_LEVEL) {
    voiceAwake = true;
    voiceAwakeUntil = millis() + MIC_LISTEN_MS;
    roboEyes.setMood(HAPPY);
    startMoodWav(CLIP_READY);
    Serial.println("Pixel is listening");
  }

  if (voiceAwake) {
    String cmd = recognizeVoiceCommand();
    if (cmd.length() > 0) {
      handleCommand(cmd);
      voiceAwake = false;
    } else if (millis() > voiceAwakeUntil) {
      voiceAwake = false;
      Serial.println("Voice listen timeout");
    }
  }
}

// =====================================================
// INFO SCREEN
// =====================================================
void showInfoScreen() {
  display.clearDisplay();
  display.setTextColor(OLED_WHITE);

  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Hi, I Am");

  display.setTextSize(3);
  display.setCursor(13, 22);
  display.print("Pixel");

  display.setTextSize(1);
  display.setCursor(18, 54);
  display.print("A ROBO DOG");

  display.display();
}

// =====================================================
// BLE UART
// =====================================================
#define BLE_DEVICE_NAME        "Pixel"
#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

BLECharacteristic* pTxCharacteristic;
bool   bleConnected = false;
String bleBuffer    = "";

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    bleConnected = true;
    Serial.println("BLE connected");
    roboEyes.setMood(HAPPY);
  }
  void onDisconnect(BLEServer* pServer) {
    bleConnected = false;
    Serial.println("BLE disconnected");
    pServer->startAdvertising();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* pCharacteristic) {
    String val = pCharacteristic->getValue().c_str();
    val.trim();
    if (val.length() > 0) bleBuffer = val;
  }
};

void bleSend(const char* msg) {
  if (bleConnected) {
    pTxCharacteristic->setValue(msg);
    pTxCharacteristic->notify();
  }
}

void initBLE() {
  BLEDevice::init(BLE_DEVICE_NAME);
  BLEServer* pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());
  BLEService* pService = pServer->createService(SERVICE_UUID);
  pTxCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
  pTxCharacteristic->addDescriptor(new BLE2902());
  BLECharacteristic* pRx = pService->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pRx->setCallbacks(new RxCallbacks());
  pService->start();
  BLEAdvertising* pAdv = BLEDevice::getAdvertising();
  pAdv->addServiceUUID(SERVICE_UUID);
  pAdv->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("BLE advertising as: " BLE_DEVICE_NAME);
}

// =====================================================
// SERVO CONFIGURATION
// =====================================================
#define CENTER       90
#define SERVOMIN     0
#define SERVOMAX     180
#define NUM_SERVOS   4
#define DELAY_TIME   5
#define SPEED_FACTOR 0.5f
#define MAX_STEP     3
#define MOVE_STEPS   35

const int SERVO_PINS[NUM_SERVOS] = {0, 1, 2, 3};

const float FREQUENCY            = 0.005f;
const float AMPLITUDE            = 30.0f;
const float gPhase[NUM_SERVOS]       = { 0, 0, PI - PI/2, PI - PI/2 };
const float off_set_walk[NUM_SERVOS] = { -10, 10, 40, -40 };

unsigned long currentMillis = 0, oldMillis = 0, innerTime = 0;
float currentPos[NUM_SERVOS], targetPos[NUM_SERVOS];
int   lastPulse[NUM_SERVOS];

enum Mode {
  MODE_REST,
  MODE_INFO,
  MODE_IDLE,
  MODE_WALK_FORWARD,
  MODE_WALK_BACKWARD,
  MODE_WALK_LEFT,
  MODE_WALK_RIGHT,
  MODE_SPIN_LEFT,
  MODE_SPIN_RIGHT,
  MODE_BARK
};
Mode currentMode = MODE_REST;

Servo servos[NUM_SERVOS];

void writeServo(int i, float deg) {
  servos[i].write(constrain((int)deg, SERVOMIN, SERVOMAX));
}

void moveUntilReachedAll() {
  float startPos[NUM_SERVOS];
  for (int i = 0; i < NUM_SERVOS; i++) startPos[i] = currentPos[i];
  for (int step = 1; step <= MOVE_STEPS; step++) {
    float t = (float)step / (float)MOVE_STEPS;
    for (int i = 0; i < NUM_SERVOS; i++) {
      currentPos[i] = startPos[i] + t * (targetPos[i] - startPos[i]);
      lastPulse[i]  = (int)currentPos[i];
      writeServo(i, currentPos[i]);
    }
    serviceWav();
    roboEyes.update();
    delay(DELAY_TIME);
  }
}

void updateAllServos() {
  for (int i = 0; i < NUM_SERVOS; i++) {
    float diff = targetPos[i] - currentPos[i];
    if (fabsf(diff) > 0.5f)
      currentPos[i] += constrain(diff * SPEED_FACTOR, -(float)MAX_STEP, (float)MAX_STEP);
    writeServo(i, currentPos[i]);
  }
  delay(DELAY_TIME);
}

void syncCurrentPos() {
  for (int i = 0; i < NUM_SERVOS; i++) {
    currentPos[i] = (float)lastPulse[i];
    targetPos[i]  = (float)lastPulse[i];
  }
}

// =====================================================
// POSES
// =====================================================
void runUpSequence() {
  for (int i = 0; i < NUM_SERVOS; i++) targetPos[i] = CENTER;
  moveUntilReachedAll();
}

void runDownSequence() {
  targetPos[0] = CENTER + 90;
  targetPos[1] = CENTER - 90;
  targetPos[2] = CENTER + 90;
  targetPos[3] = CENTER - 90;
  moveUntilReachedAll();
}

void runSitSequence() {
  targetPos[0] = CENTER;
  targetPos[1] = CENTER;
  targetPos[2] = CENTER - 40;
  targetPos[3] = CENTER + 40;
  moveUntilReachedAll();
}

void runPushupsSequence() {
  roboEyes.setMood(ANGRY);
  for (int r = 0; r < 6; r++) {
    targetPos[0]=CENTER+30; targetPos[1]=CENTER-30;
    targetPos[2]=CENTER-30; targetPos[3]=CENTER+30;
    moveUntilReachedAll(); delay(150);
    targetPos[0]=CENTER; targetPos[1]=CENTER;
    targetPos[2]=CENTER; targetPos[3]=CENTER;
    moveUntilReachedAll(); delay(150);
  }
  runUpSequence();
  roboEyes.setMood(DEFAULT);
}

void runSwingSequence() {
  roboEyes.setMood(HAPPY);
  for (int i = 0; i < 4; i++) {
    targetPos[0]=CENTER+35; targetPos[1]=CENTER; targetPos[2]=CENTER; targetPos[3]=CENTER-35;
    moveUntilReachedAll(); delay(150);
    targetPos[0]=CENTER; targetPos[1]=CENTER-35; targetPos[2]=CENTER+35; targetPos[3]=CENTER;
    moveUntilReachedAll(); delay(150);
  }
  runUpSequence(); roboEyes.setMood(DEFAULT);
}

void runGallopSequence() {
  roboEyes.setMood(HAPPY);
  bool hasAudio = startMoodWav(CLIP_GALLOP);
  for (int i = 0; i < 8; i++) {
    targetPos[0]=CENTER+40; targetPos[1]=CENTER-40; targetPos[2]=CENTER-40; targetPos[3]=CENTER+40;
    moveUntilReachedAll(); audioDelay(80);
    targetPos[0]=CENTER-40; targetPos[1]=CENTER+40; targetPos[2]=CENTER+40; targetPos[3]=CENTER-40;
    moveUntilReachedAll(); audioDelay(80);
  }
  runUpSequence();
  currentMode = MODE_IDLE;
  if (!hasAudio) wakeEyes();
}

void drawBarkMouth(bool open) {
  if (open) {
    display.fillRoundRect(51, 45, 26, 12, 3, OLED_WHITE);
    display.fillRect(56, 48, 16, 6, OLED_BLACK);
  } else {
    display.drawLine(52, 50, 76, 50, OLED_WHITE);
  }
  display.display();
}

void runBarkSequence() {
  currentMode = MODE_BARK;
  syncCurrentPos();
  roboEyes.setMood(ANGRY);
  bool hasAudio = startMoodWav(CLIP_BARK);

  for (int i = 0; i < 6; i++) {
    targetPos[0]=CENTER+18; targetPos[1]=CENTER-18;
    targetPos[2]=CENTER+12; targetPos[3]=CENTER-12;
    moveUntilReachedAll();
    roboEyes.update();
    drawBarkMouth(true);
    audioDelay(80);

    targetPos[0]=CENTER-8; targetPos[1]=CENTER+8;
    targetPos[2]=CENTER-8; targetPos[3]=CENTER+8;
    moveUntilReachedAll();
    roboEyes.update();
    drawBarkMouth(false);
    audioDelay(80);
  }

  runUpSequence();
  currentMode = MODE_IDLE;
  if (!hasAudio) wakeEyes();
}

// =====================================================
// GAIT ENGINE
// =====================================================
void runGait(const float ampScale[NUM_SERVOS]) {
  oldMillis = currentMillis; currentMillis = millis();
  innerTime += currentMillis - oldMillis;
  float t = FREQUENCY * (float)innerTime;
  for (int s = 0; s < NUM_SERVOS; s++) {
    float deg = CENTER + off_set_walk[s] + ampScale[s] * AMPLITUDE * cosf(t + gPhase[s]);
    deg = constrain(deg, SERVOMIN, SERVOMAX);
    writeServo(s, deg); lastPulse[s] = (int)deg;
  }
  delay(DELAY_TIME);
}

// =====================================================
// REST & INFO
// =====================================================
void enterRest() {
  syncCurrentPos();
  runDownSequence();
  display.clearDisplay();
  display.display();
  roboEyes.setIdleMode(OFF, 0, 0);
  roboEyes.setAutoblinker(ON, 4, 1);
  roboEyes.setMood(TIRED);
}

void enterInfo() {
  syncCurrentPos();
  runSitSequence();
  display.clearDisplay();
  display.display();
  roboEyes.setMood(HAPPY);
  infoPresentationHasAudio = startMoodWav(CLIP_INFO);
  infoPresentationActive = true;
  infoPresentationStartedAt = millis();
  showInfoScreen();
}

void updateInfo() {
  if (infoPresentationActive) {
    bool audioFinished = infoPresentationHasAudio && !audioPlaying;
    bool noAudioFallbackDone = !infoPresentationHasAudio && millis() - infoPresentationStartedAt > 3000;

    if (audioFinished || noAudioFallbackDone) {
      infoPresentationActive = false;
      infoPresentationHasAudio = false;
      wakeEyes();
      syncCurrentPos();
      runUpSequence();
      currentMode = MODE_IDLE;
    }
  }
}

void wakeEyes() {
  roboEyes.setIdleMode(ON, 2, 2);
  roboEyes.setAutoblinker(ON, 3, 2);
  roboEyes.setMood(DEFAULT);
}

// =====================================================
// COMMAND HANDLER
// =====================================================
void handleCommand(String input) {
  input.trim(); input.toUpperCase();
  if (input.length() == 0) return;
  stopWav();
  infoPresentationActive = false;
  infoPresentationHasAudio = false;
  audioMoodReturnPending = false;
  Serial.println(input); bleSend(input.c_str());

  if      (input == "REST")     { currentMode = MODE_REST;          enterRest();                           }
  else if (input == "INFO")     { currentMode = MODE_INFO;          enterInfo();                           }
  else if (input == "WALK")     { currentMode = MODE_WALK_FORWARD;  wakeEyes(); syncCurrentPos(); runUpSequence(); }
  else if (input == "BACK")     { currentMode = MODE_WALK_BACKWARD; wakeEyes(); syncCurrentPos(); runUpSequence(); }
  else if (input == "LEFT")     { currentMode = MODE_WALK_LEFT;     wakeEyes();                            }
  else if (input == "RIGHT")    { currentMode = MODE_WALK_RIGHT;    wakeEyes();                            }
  else if (input == "SL")       { currentMode = MODE_SPIN_LEFT;     wakeEyes();                            }
  else if (input == "SR")       { currentMode = MODE_SPIN_RIGHT;    wakeEyes();                            }
  else if (input == "STOP")     { currentMode = MODE_IDLE;          roboEyes.setMood(DEFAULT); stopWav();   }
  else if (input == "BARK")     { runBarkSequence();                                                     }
  else if (input == "PUSHUPS")  { currentMode = MODE_IDLE; syncCurrentPos(); runPushupsSequence();         }
  else if (input == "SWING")    { currentMode = MODE_IDLE; syncCurrentPos(); runSwingSequence();           }
  else if (input == "GALLOP")   { currentMode = MODE_IDLE; syncCurrentPos(); runGallopSequence();          }
  else if (input == "UP")       { currentMode = MODE_IDLE; syncCurrentPos(); runUpSequence();              }
  else if (input == "DOWN")     { currentMode = MODE_IDLE; syncCurrentPos(); runDownSequence();            }
  else if (input == "HEY PIXEL" || input == "PIXEL") {
    voiceAwake = true;
    voiceAwakeUntil = millis() + MIC_LISTEN_MS;
    roboEyes.setMood(HAPPY);
    startMoodWav(CLIP_READY);
  }
  else { Serial.print("Unknown: "); Serial.println(input); }
}

// =====================================================
// SETUP
// =====================================================
void setup() {
  Serial.begin(115200);

  Wire.begin(I2C_SDA, I2C_SCL);
  delay(250);
  if (!display.begin(SSD1306_SWITCHCAPVCC, i2c_Address)) {
    Serial.println("SSD1306 OLED allocation failed");
  }
  display.clearDisplay();
  display.display();
  roboEyes.begin(SCREEN_WIDTH, SCREEN_HEIGHT, 100);
  roboEyes.setAutoblinker(ON, 3, 2);
  roboEyes.setIdleMode(ON, 2, 2);
  roboEyes.setCuriosity(ON);

  initAudioOut();
  initMic();
  initBLE();

  for (int i = 0; i < NUM_SERVOS; i++) {
    servos[i].attach(SERVO_PINS[i]);
    currentPos[i] = targetPos[i] = lastPulse[i] = CENTER;
    writeServo(i, CENTER);
    delay(100);
  }

  syncCurrentPos();
  runUpSequence();
  wakeEyes();
  currentMode = MODE_IDLE;
  Serial.println("Pixel ready!");
}

// =====================================================
// LOOP
// =====================================================
void loop() {
  serviceWav();
  updateVoiceInput();

  if (Serial.available() > 0) handleCommand(Serial.readStringUntil('\n'));
  if (bleBuffer.length() > 0) { handleCommand(bleBuffer); bleBuffer = ""; }

  if (audioMoodReturnPending) {
    audioMoodReturnPending = false;
    infoPresentationActive = false;
    infoPresentationHasAudio = false;
    wakeEyes();
    syncCurrentPos();
    runUpSequence();
    currentMode = MODE_IDLE;
  }

  switch (currentMode) {
    case MODE_REST:          roboEyes.update(); break;
    case MODE_INFO:          updateInfo();      break;
    case MODE_WALK_FORWARD:  { static const float a[] = { 1.0f,  1.0f,  1.0f,  1.0f }; runGait(a); roboEyes.update(); break; }
    case MODE_WALK_BACKWARD: { static const float a[] = {-1.0f, -1.0f, -1.0f, -1.0f }; runGait(a); roboEyes.update(); break; }
    case MODE_WALK_LEFT:     { static const float a[] = { 0.3f,  0.3f,  1.5f,  1.5f }; runGait(a); roboEyes.update(); break; }
    case MODE_WALK_RIGHT:    { static const float a[] = { 1.5f,  1.5f,  0.3f,  0.3f }; runGait(a); roboEyes.update(); break; }
    case MODE_SPIN_LEFT:     { static const float a[] = { 1.2f, -1.2f,  1.2f, -1.2f }; runGait(a); roboEyes.update(); break; }
    case MODE_SPIN_RIGHT:    { static const float a[] = {-1.2f,  1.2f, -1.2f,  1.2f }; runGait(a); roboEyes.update(); break; }
    case MODE_BARK:          serviceWav();      break;
    default: updateAllServos(); roboEyes.update(); break;
  }
}
